import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Integer Number:");
        int a = sc.nextInt();
        sc.nextLine();

        System.out.println("Enter String:");
        String s = sc.nextLine();

        System.out.println("Enter Float Number:");
        float f = sc.nextFloat();

        System.out.println("Hello World");
        System.out.println(a);
        System.out.println(s);
        System.out.println(f);

        sc.close();
    }
}
